/*
 * Copyright (c) 2013 Chun-Ying Huang
 *
 * This file is part of Gaming Anywhere (GA).
 *
 * GA is free software; you can redistribute it and/or modify it
 * under the terms of the 3-clause BSD License as published by the
 * Free Software Foundation: http://directory.fsf.org/wiki/License:BSD_3Clause
 *
 * GA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * You should have received a copy of the 3-clause BSD License along with GA;
 * if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef __GA_HOOK_SDL_H__
#define __GA_HOOK_SDL_H__

#include <SDL2/SDL.h>
#include "sdl12-event.h"
#include "sdl12-mouse.h"

#ifdef __cplusplus
extern "C" {
#endif
typedef int	(*t_SDL_Init)(unsigned int);
typedef void	(*t_SDL_GL_SwapBuffers)();
typedef int	(*t_SDL_PollEvent)(SDL_Event *);
typedef int	(*t_SDL_PushEvent)(SDL12_Event *);
#ifdef __cplusplus
}
#endif

extern t_SDL_Init		old_SDL_Init;
extern t_SDL_GL_SwapBuffers	old_SDL_GL_SwapBuffers;
extern t_SDL_PollEvent		old_SDL_PollEvent;
extern t_SDL_PushEvent		old_SDL_PushEvent;

int hook_SDL_Init(unsigned int flags);
void hook_SDL_GL_SwapBuffers();
int hook_SDL_PollEvent(SDL_Event *event);

void sdl12_mapinit();
void sdl_hook_replay_callback(void *msg, int msglen);

#endif
